# Management_de_projet

Projet 15 : Création d'un site de commerce electronique en ligne

- Faire le Github
- Etablir le planning du projet :
- Attribuer les tâches :
- Choix du langage de programmation, du framework et de la base de donnée :
- Documenter les élèments
- Faire une maquette de la plateforme
