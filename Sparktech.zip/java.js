document.getElementById('paymentForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Empêcher la soumission du formulaire pour la démo

    // Ici, vous ajouterez la validation du formulaire
    // et la logique d'intégration avec le système de paiement

    alert('Paiement simulé pour la démonstration');
});
